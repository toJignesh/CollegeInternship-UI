export interface Job{
    id:number;
    title:string;
    description:string;
    postalCode:string;
    longitude:number;
    latitude:number;
}